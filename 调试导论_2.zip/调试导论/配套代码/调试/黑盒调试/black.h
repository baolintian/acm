void fun1()
{
    ;
}

void fun2()
{
    ;
}

void fun3()
{
    ;
}

void fun4()
{
    ;
}

void fun5()
{
    while(1);
}

void fun6()
{
    ;
}